import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import '@heroui/react/styles'
import './index.css'
import App from './App.jsx'
import { registerSW } from "virtual:pwa-register"

registerSW({
  immediate: true,
  onNeedRefresh() { window.location.reload(); }
})

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <App />
  </StrictMode>,
)
