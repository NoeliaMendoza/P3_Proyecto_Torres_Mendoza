import { Header } from '../header';
import { Footer } from '../footer';
import { Sidebar } from './sidebar';
import { useUIStore } from '../../store';
import styles from './layout.module.css';

export const Layout = ({ children }) => {
  const sidebarOpen = useUIStore((s) => s.sidebarOpen);

  return (
    <div className={styles.contenedor}>
      <Sidebar />
      <div className={`${styles.mainArea} ${sidebarOpen ? styles.shifted : ''}`}>
        <Header />
        <main className={styles.main}>{children}</main>
        <Footer />
      </div>
    </div>
  );
};
