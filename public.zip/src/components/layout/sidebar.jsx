import { NavLink } from 'react-router-dom';
import { useUIStore } from '../../store';
import styles from './sidebar.module.css';

const navItems = [
  { label: 'Dashboard', path: '/dashboard', icon: '📊' },
  { label: 'Espacios Académicos', path: '/espacios', icon: '🏛️' },
  { label: 'Horarios', path: '/horarios', icon: '📅' },
  { label: 'Objetos Perdidos', path: '/objetos-perdidos', icon: '🔍' },
];

export const Sidebar = () => {
  const { sidebarOpen, setSidebarOpen } = useUIStore();

  const handleNavClick = () => {
    if (window.innerWidth <= 768) setSidebarOpen(false);
  };

  return (
    <>
      {sidebarOpen && <div className={styles.overlay} onClick={() => setSidebarOpen(false)} />}
      <aside className={`${styles.sidebar} ${sidebarOpen ? styles.open : ''}`}>
        <div className={styles.logo}>
          <div className={styles.logoIcon}>E</div>
          <span className={styles.logoText}>ESPEConnect</span>
        </div>
        <nav className={styles.nav}>
          {navItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              onClick={handleNavClick}
              className={({ isActive }) =>
                `${styles.navItem} ${isActive ? styles.active : ''}`
              }
            >
              <span>{item.icon}</span>
              <span>{item.label}</span>
            </NavLink>
          ))}
        </nav>
        <div className={styles.footer}>
          <p className={styles.copy}>&copy; {new Date().getFullYear()} ESPEConnect</p>
        </div>
      </aside>
    </>
  );
};
