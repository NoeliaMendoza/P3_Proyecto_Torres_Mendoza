import api from '../api/axios';

export const obtenerEspacios = async (params) => {
  const response = await api.get('/espacios', { params });
  return response.data;
};

export const obtenerUnEspacio = async (id) => {
  const response = await api.get(`/espacios/${id}`);
  return response.data;
};

export const obtenerDisponibilidad = async (id) => {
  const response = await api.get(`/espacios/${id}/disponibilidad`);
  return response.data;
};

export const obtenerTiposEspacio = async () => {
  const response = await api.get('/espacios/tipos');
  return response.data;
};
