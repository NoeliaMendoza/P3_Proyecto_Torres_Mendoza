import api from '../api/axios';

export const login = async (correo, password) => {
  const response = await api.post('/auth/login', { correo, password });
  return response.data;
};

export const register = async (nombre, correo, password) => {
  const response = await api.post('/auth/register', { nombre, correo, password });
  return response.data;
};

export const perfil = async () => {
  const response = await api.get('/auth/perfil');
  return response.data;
};
