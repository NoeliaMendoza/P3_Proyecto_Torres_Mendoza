import api from '../api/axios';

export const obtenerObjetos = async (params) => {
  const response = await api.get('/objetos-perdidos', { params });
  return response.data;
};

export const obtenerUnObjeto = async (id) => {
  const response = await api.get(`/objetos-perdidos/${id}`);
  return response.data;
};

export const crearObjeto = async (data) => {
  const response = await api.post('/objetos-perdidos', data);
  return response.data;
};

export const actualizarObjeto = async (id, data) => {
  const response = await api.put(`/objetos-perdidos/${id}`, data);
  return response.data;
};

export const eliminarObjeto = async (id) => {
  const response = await api.delete(`/objetos-perdidos/${id}`);
  return response.data;
};

export const obtenerCategorias = async () => {
  const response = await api.get('/objetos-perdidos/categorias');
  return response.data;
};

export const reclamarObjeto = async (id) => {
  const response = await api.post(`/objetos-perdidos/${id}/reclamar`);
  return response.data;
};
