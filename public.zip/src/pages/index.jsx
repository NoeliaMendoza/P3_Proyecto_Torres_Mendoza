export { LoginPages } from "./login";
export { DashboardPages } from "./dashboard";
export { AcademicSpacesPages } from "./academic-spaces";
export { LostObjectsPages } from "./lost-objects";
export { SchedulePages } from "./schedule";
