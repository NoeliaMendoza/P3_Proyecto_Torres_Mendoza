import { useQuery } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardContent } from '@heroui/react';
import { useAuthStore } from '../../store';
import { obtenerEspacios } from '../../services/espacios.services';
import { obtenerObjetos } from '../../services/objetos.services';

const iconos = {
  'Espacios disponibles': { icon: '🏛️', color: '#22c55e', bg: '#f0fdf4' },
  'Objetos perdidos': { icon: '🔍', color: '#ef4444', bg: '#fef2f2' },
  'Objetos encontrados': { icon: '📦', color: '#f59e0b', bg: '#fffbeb' },
  'Mis reportes': { icon: '📋', color: '#3b82f6', bg: '#eff6ff' },
};

export const DashboardPages = () => {
  const usuario = useAuthStore((s) => s.usuario);

  const { data: espacios = [] } = useQuery({ queryKey: ['espacios', 'dashboard'], queryFn: () => obtenerEspacios() });
  const { data: perdidos = [] } = useQuery({ queryKey: ['objetos', 'perdido'], queryFn: () => obtenerObjetos({ tipo: 'perdido' }) });
  const { data: encontrados = [] } = useQuery({ queryKey: ['objetos', 'encontrado'], queryFn: () => obtenerObjetos({ tipo: 'encontrado' }) });

  const disponibles = espacios.filter((e) => e.estado === 'disponible').length;
  const misReportes = [...perdidos, ...encontrados].filter((o) => o.reportante_nombre === usuario?.nombre).length;

  const stats = [
    { title: 'Espacios disponibles', value: disponibles },
    { title: 'Objetos perdidos', value: perdidos.length },
    { title: 'Objetos encontrados', value: encontrados.length },
    { title: 'Mis reportes', value: misReportes },
  ];

  return (
    <div className="max-w-7xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900">Dashboard</h1>
        <p className="text-sm text-slate-500 mt-1">Bienvenido, {usuario?.nombre || 'usuario'}</p>
      </div>
      <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((s) => {
          const meta = iconos[s.title];
          return (
            <Card key={s.title} className="p-5">
              <CardHeader className="flex items-center gap-3 px-0 pt-0">
                <span className="text-2xl">{meta.icon}</span>
                <CardTitle className="text-sm font-medium text-slate-500">{s.title}</CardTitle>
              </CardHeader>
              <CardContent className="px-0 pb-0">
                <p className="text-3xl font-bold text-slate-900">{s.value}</p>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
};
