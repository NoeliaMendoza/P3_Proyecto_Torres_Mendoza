export { AcademicSpacesPages } from "./academic-spaces";
