import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { login } from '../../services/auth.services';
import { useAuthStore } from '../../store';
import styles from './login.module.css';

export const LoginPages = () => {
  const [correo, setCorreo] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const loginStore = useAuthStore((s) => s.login);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const data = await login(correo, password);
      loginStore(data.usuario, data.token);
      navigate('/dashboard');
    } catch (err) {
      setError(err.response?.data?.mensaje || 'Error al iniciar sesión');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={styles.container}>
      <div className={styles.card}>
        <div className={styles.header}>
          <div className={styles.logo}>E</div>
          <h1 className={styles.title}>ESPEConnect</h1>
          <p className={styles.subtitle}>Inicia sesión para continuar</p>
        </div>
        <form onSubmit={handleSubmit} className={styles.form}>
          {error && <div className={styles.error}>{error}</div>}
          <div className={styles.field}>
            <label className={styles.label}>Correo institucional</label>
            <input type="email" value={correo} onChange={(e) => setCorreo(e.target.value)}
              className={styles.input} placeholder="ejemplo@espe.edu.ec" required />
          </div>
          <div className={styles.field}>
            <label className={styles.label}>Contraseña</label>
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)}
              className={styles.input} placeholder="••••••••" required />
          </div>
          <button type="submit" disabled={loading} className={styles.button}>
            {loading ? 'Iniciando sesión...' : 'Iniciar sesión'}
          </button>
        </form>
      </div>
    </div>
  );
};
