# ESPEConnect 🎓

Plataforma universitaria para la comunidad de la Universidad de las Fuerzas Armadas ESPE.
Conecta a los estudiantes con los servicios del campus: **espacios académicos** y **objetos perdidos**.

---

## Requisitos

| Herramienta | Versión |
|-------------|---------|
| Node.js | 22+ |
| PostgreSQL | 16+ |
| npm | 10+ |

---

## Instalación y ejecución

### 1. Clonar el repositorio

```bash
git clone <url-del-repo>
cd Proyecto
```

### 2. Configurar la base de datos

Asegúrate de que PostgreSQL esté corriendo y ejecuta:

```bash
# En Windows (PowerShell):
$env:PGPASSWORD = "admin"
"C:\Program Files\PostgreSQL\16\bin\psql.exe" -U postgres -c "CREATE DATABASE espe_connect;"
"C:\Program Files\PostgreSQL\16\bin\psql.exe" -U postgres -d espe_connect -f database/schema.sql

# En Linux/Mac:
psql -U postgres -c "CREATE DATABASE espe_connect;"
psql -U postgres -d espe_connect -f database/schema.sql
```

> **Nota**: Si tu PostgreSQL tiene otra contraseña, edita `server/.env` y cambia `DB_PASSWORD`.

### 3. Instalar dependencias

```bash
# Frontend
npm install

# Backend
cd server
npm install
cd ..
```

### 4. Iniciar el backend

```bash
cd server
npm run dev
```

El backend se ejecutará en `http://localhost:3000`.

### 5. Iniciar el frontend

Abre otra terminal:

```bash
cd Proyecto
npm run dev
```

El frontend se ejecutará en `http://localhost:5173`.

### 6. Registrar un usuario de prueba

```bash
curl -X POST http://localhost:3000/auth/register \
  -H "Content-Type: application/json" \
  -d '{"nombre":"Tu Nombre","correo":"test@espe.edu.ec","password":"123456"}'
```

O usa el login con las credenciales ya registradas:

| Campo | Valor |
|-------|-------|
| Correo | `test@espe.edu.ec` |
| Contraseña | `123456` |

---

## Estructura del proyecto

```
Proyecto/
├── src/                    # Frontend (React 19 + Vite + PWA)
│   ├── pages/              # Login, Dashboard, Espacios, Objetos, Horarios
│   ├── components/         # Header, Footer, Sidebar, Layout
│   ├── services/           # auth, espacios, horarios, objetos
│   ├── store/              # Zustand (auth, ui)
│   ├── routes/             # PrivateRoutes
│   └── api/axios.js        # Cliente HTTP
│
├── server/                 # Backend (Express + JWT + PostgreSQL)
│   ├── routes/             # auth, usuarios, espacios, horarios, objetos
│   ├── middlewares/        # authentication, authorization
│   ├── database/conexion.js
│   └── config/jwt.js
│
├── database/schema.sql     # Script de la base de datos
└── docker-compose.yml      # Opcional: levantar todo con Docker
```

---

## Tecnologías

| Frontend | Backend |
|----------|---------|
| React 19 | Express 5 |
| Vite 8 | JWT (jsonwebtoken) |
| React Router 7 | bcrypt |
| TanStack Query 5 | PostgreSQL (pg) |
| Zustand 5 | CORS |
| HeroUI | Dotenv |
| Axios | Nodemon |
| PWA (vite-plugin-pwa) | |

---

## Ejecutar con Docker (opcional)

```bash
docker compose up --build
```

Esto levanta PostgreSQL, backend y frontend automáticamente.
